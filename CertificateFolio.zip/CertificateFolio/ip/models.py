from django.db import models

# Create your models here.
class Certificate(models.Model):
    Certificate_id = models.AutoField
    Certificate_title = models.CharField(max_length=50)
    Certificate_imageurl = models.CharField(max_length=1000)
    Certificate_desc = models.TextField( blank=True)

from django.contrib import admin
from .models import Certificate

# Register your models here.
admin.site.register(Certificate)

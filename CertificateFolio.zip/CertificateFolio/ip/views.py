from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Certificate

# Create your views here.
def Index(request):
     certificate=Certificate.objects.all()
     return render(request,'index.html',{'certificate':certificate})
